package com.swarmtestbed.neighbourhoods;


import java.util.ArrayList;
import java.util.logging.Level;

import com.swarmtestbed.heuristics.PSO.BaseSwarm;
import com.swarmtestbed.util.Log;
import com.swarmtestbed.util.Particle;


public class Star extends Topology
{

	public Star(BaseSwarm swarm)
	{
		super(swarm);
		setDescription("FIPS: Gbest or Star Topology");
	}

	@Override
	protected ArrayList<Particle> getNeighbourhood(int particle)
			throws Exception
	{
		ArrayList<Particle> neighbourhood = null;
		try
		{
			ArrayList<Particle> swarmMembers = swarm.getSwarmMembers();
			if (swarmMembers != null)
				neighbourhood = new ArrayList<Particle>(swarmMembers);
			// Remove the current particle from the neighbourhood
			if (neighbourhood != null && neighbourhood.size() != 0)
				neighbourhood.remove(particle);
			else
				throw new Exception(
						"Star Topology returned a null neighbourhood particle ="
								+ particle);

		} catch (ArrayIndexOutOfBoundsException e)
		{
			Log.log(Level.SEVERE, new Exception(e.getMessage() + " particle="
					+ particle + " neighbourhood size=" + neighbourhood.size(),
					e));
			// e.printStackTrace();
		}
		neighbourhoodXML(particle, neighbourhood);
		return neighbourhood;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.swarmtestbed.neighbourhoods.Topology#createParams()
	 */
	@Override
	public void createParams()
	{

	}

}
