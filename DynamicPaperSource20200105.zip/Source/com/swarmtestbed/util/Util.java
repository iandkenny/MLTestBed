/**
 * 
 */
package com.swarmtestbed.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.TimeZone;
import com.swarmtestbed.ui.SwarmUI;

/**
 * @author Ian Kenny
 * 
 */
public class Util
{
	private static long minMem;
	private static Runtime runtime = Runtime.getRuntime();
	private static SwarmUI swarmui;

	public static boolean checkMemFree()
	{
		runtime.gc();
		return runtime.freeMemory() < (minMem * 4);

	}
	public static String formatRuntime(long l)
	{
		String format = "";
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(l);
		cal.setTimeZone(TimeZone.getTimeZone("GMT"));
		try
		{
			NumberFormat numberInstance = NumberFormat.getNumberInstance();
			numberInstance.setMinimumIntegerDigits(2);
			Integer day = cal.get(Calendar.DAY_OF_YEAR) - 1;
			Integer hour = cal.get(Calendar.HOUR_OF_DAY);
			Integer minute = cal.get(Calendar.MINUTE);
			Integer sec = cal.get(Calendar.SECOND);
			format = ((day == null) ? "00" : numberInstance.format(day)) + ":"
					+ ((hour == null) ? "00" : numberInstance.format(hour))
					+ ":"
					+ ((minute == null) ? "00" : numberInstance.format(minute))
					+ ":" + ((sec == null) ? "00" : numberInstance.format(sec));
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return format;
	}

	/**
	 * @return the swarmui
	 */
	public static SwarmUI getSwarmui()
	{
		return swarmui;
	}
	public static void copyFile(File sourceFile, File destFile)
			throws IOException
	{
		if (!destFile.exists())
		{
			destFile.createNewFile();
		}

		FileChannel source = null;
		FileChannel destination = null;
		FileOutputStream fileOutputStream = null;
		FileInputStream fileInputStream = null;

		try
		{
			fileInputStream = new FileInputStream(sourceFile);
			source = fileInputStream.getChannel();
			fileOutputStream = new FileOutputStream(destFile);
			destination = fileOutputStream.getChannel();
			destination.transferFrom(source, 0, source.size());
		} finally
		{
			if (source != null)
			{
				source.close();
			}
			if (destination != null)
			{
				destination.close();
			}
			if (fileOutputStream != null)
			{
				fileOutputStream.close();
			}
			if (fileInputStream != null)
			{
				fileInputStream.close();
			}
		}
	}
	public static File createTempFile() throws IOException
	{
		File file = null;
		try
		{
			(file = File.createTempFile("swarm", null)).deleteOnExit();
		} catch (IllegalStateException e)
		{
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return file;
	}
	public Util()
	{
		minMem = runtime.freeMemory() / 10;
	}
	public Util(SwarmUI ui)
	{
		swarmui = ui;
		minMem = runtime.freeMemory() / 10;
	}
	public static boolean isNumeric(String str)
	{
		return str.matches("-?\\d+(\\.\\d+)?"); // match a number with optional
												// '-' and decimal.
	}
}
