/*
 * Created on 12-Mar-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.swarmtestbed.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.util.Properties;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Level;

import com.swarmtestbed.testFunctions.TestBase;

/**
 * @author Ian Kenny
 * 
 *         TODO To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Style - Code Templates
 */
public class Particle implements Comparable<Particle>, Cloneable
{
	public static String[] getSupportedVelocityInit()
	{
		String buf[] =
		{"zero", "position", "random"};
		return buf;
	}
	private double bestScore = Double.NaN;
	private double currentScore = Double.NaN;
	private double previousScore = Double.NaN;
	private double avgchangesum = 0;
	private int identityNumber;
	private long mDimension;
	private Vector<Double> mPosition;
	private Vector<Double> mPreviousPosition;
	private Vector<Double> mVelocity;
	private Properties params;
	private Vector<Double> pbest;
	private TestBase testFunction;
	private File tmpFile = null;
	private long previousCount = 0;

	/**
	 *  
	 */
	public Particle(Properties params, TestBase T, Random random,
			int identityNumber)
	{
		try
		{
			this.params = params;
			testFunction = (TestBase) T.clone();
			// testFunction = T;
			mDimension = testFunction.getMDimension();
			bestScore = (testFunction.isMinimised())
					? Double.MAX_VALUE
					: Double.MIN_VALUE;
			currentScore = (testFunction.isMinimised())
					? Double.MAX_VALUE
					: Double.MIN_VALUE;
			mPosition = init(testFunction, random);
			pbest = new Vector<Double>(mPosition);
			mPreviousPosition = new Vector<Double>(mPosition);
			this.identityNumber = identityNumber;
		} catch (Exception e)
		{
			Log.log(Level.SEVERE, new Exception(
					"Particle Initialisation failed: " + e.getMessage(), e));
			// e.printStackTrace();
		}
	}

	public Particle(Particle o)
	{
		super();
		this.bestScore = o.bestScore;
		this.currentScore = o.currentScore;
		this.avgchangesum = o.avgchangesum;
		this.previousCount = o.previousCount;
		this.identityNumber = o.identityNumber;
		this.mDimension = o.mDimension;
		this.mPosition = new Vector<Double>(o.mPosition);
		this.mPreviousPosition = new Vector<Double>(o.mPreviousPosition);
		this.mVelocity = new Vector<Double>(o.mVelocity);
		this.params = new Properties(o.params);
		this.pbest = new Vector<Double>(o.pbest);
		this.testFunction = (TestBase) o.testFunction.clone();
		this.tmpFile = o.retrieveFileBuffer();
	}

	/**
	 * @return average rate of change in particle's score
	 */
	public double absAvgRateChange()
	{
		double d = Double.MAX_VALUE;

		if (previousScore != Double.NaN)
		{
			avgchangesum += Math
					.sqrt(Math.pow(previousScore - currentScore, 2));
			if (previousCount > 100)
				d = avgchangesum / previousCount;
			previousCount++;
		}

		return d;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() throws CloneNotSupportedException
	{
		Object clone;
		try
		{
			clone = super.clone();
			tmpFile = null;
			return clone;
		} catch (Exception e)
		{
			// This should never happen
			throw new InternalError(e.toString());
		}
	}

	public int compareTo(Particle comp)
	{
		return (int) Math.round((comp.getBestScore() - getBestScore()));
	}

	public double reEvalBest()
	{
		if (pbest != null)
		{
			bestScore = testFunction.Objective(this);
			// setFuncSpecific(p.getFuncSpecific());
		}
		return bestScore;
	}

	public double eval()
	{
		double result = Double.NaN;

		result = testFunction.Objective(this);
		// setFuncSpecific(testFunction.getFuncSpecific());
		setCurrentScore(result);

		if (testFunction.isMinimised())
		{
			if (result < bestScore)
			{

				setPbest(result);
			}
		} else
		{
			if (result > bestScore)
			{
				setPbest(result);

			}
		}
		return result;

	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#finalize()
	 */
	@Override
	protected void finalize() throws Throwable
	{
		destory();
//		super.finalize();
	}

	/**
	 * 
	 */
	public synchronized void destory()
	{
		if (tmpFile != null)
		{
			tmpFile.delete();
			tmpFile = null;
		}
		if (testFunction != null)
			testFunction.destory();
	}
	/**
	 * @return Returns current best score
	 */
	public double getBestScore()
	{
		return bestScore;
	}
	/**
	 * @return the currentScore
	 */
	public double getCurrentScore()
	{
		return currentScore;
	}
	/**
	 * @return Returns the history.
	 */
	// public LinkedList<Vector<Double>> getHistory()
	// {
	// return history;
	// }
	/**
	 * @return Returns the mDimension.
	 */
	public long getDimension()
	{
		return mDimension;
	}
	/**
	 * @return the funcSpecific
	 */
	public String getFuncSpecific()
	{
		StringBuilder funcSpecific = new StringBuilder("");
		try
		{
			// must return a non null reader

			if (tmpFile == null)
				tmpFile = Util.createTempFile();

			BufferedReader reader = null;
			reader = new BufferedReader(new FileReader(tmpFile));
			synchronized (tmpFile)
			{
				String line;
				if (reader != null)
					while ((line = reader.readLine()) != null)
						funcSpecific.append(line).append("\n");

				reader.close();
			}
			reader = null;
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

		return funcSpecific.toString();
	}
	public BufferedReader getFuncSpecificReader()
	{
		BufferedReader reader = null;
		try
		{
			// must return a non null reader

			if (tmpFile == null)
				tmpFile = Util.createTempFile();

			synchronized (tmpFile)
			{
				if (tmpFile.exists())
					reader = new BufferedReader(new FileReader(tmpFile));
				else
					reader = new BufferedReader(new StringReader(""));
			}
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

		return reader;
	}
	/**
	 * @return the identityNumber
	 */
	public int getIdentityNumber()
	{
		return identityNumber;
	}
	/**
	 * @return Returns the pbest.
	 */
	public Vector<Double> getPbest()
	{
		return pbest;
	}
	/**
	 * @return Returns the mPosition.
	 */
	public Vector<Double> getPosition()
	{
		return mPosition;
	}

	public Vector<Double> getPreviousPosition()
	{
		return mPreviousPosition;
	}

	/**
	 * @return the testFunction
	 */
	public TestBase getTestFunction()
	{
		return testFunction;
	}
	/**
	 * @return Returns the mVelocity.
	 */
	public Vector<Double> getVelocity()
	{
		return mVelocity;
	}
	private Vector<Double> init(TestBase T, Random random)
	{
		tmpFile = null;
		// Random random = new Random();
		mPosition = new Vector<Double>();
		mVelocity = new Vector<Double>();
		for (int i = 0; i < mDimension; i++)
		{
			mPosition.add(i, randInit(T, random, i));
			initVelocity(T, random, i);

		}
		return mPosition;
	}

	/**
	 * @param T
	 * @param random
	 * @param i
	 */
	private void initVelocity(TestBase T, Random random, int i)
	{
		String initVelType = params.getProperty("initveltype", "zero");
		if (initVelType.compareToIgnoreCase("random") == 0)
			mVelocity.add(i, randInit(T, random, i));
		else if (initVelType.compareToIgnoreCase("position") == 0)
			mVelocity.add(i, mPosition.get(i));
		else
			mVelocity.add(i, 0.0);
	}
	/**
	 * @param T
	 * @param random
	 * @param i
	 * @return random double in range
	 */
	private double randInit(TestBase T, Random random, int i)
	{
		double abs = Math.abs(T.getMin(i));
		return (abs + T.getMax(i) * random.nextDouble()) - abs;
		// the initialise below puts all the particles in positive space
		// return (T.getMMin(i) + (T.getMMax(i) - T.getMMin(i)))
		// * random.nextDouble();
	}
	/**
	 * @param currentScore
	 *            the currentScore to set
	 */
	public void setCurrentScore(double currentScore)
	{
		this.previousScore = this.currentScore;
		this.currentScore = currentScore;
	}
	/**
	 * @param dimension
	 *            The mDimension to set.
	 */
	public void setDimension(int dimension)
	{
		mDimension = dimension;
	}
	public void setFuncSpecific(String funcSpecific)
	{
		BufferedWriter writer = null;
		// this.funcSpecific = new String(funcSpecific);

		try
		{
			if (tmpFile == null)
				tmpFile = Util.createTempFile();
			else
			{
				RandomAccessFile randomAccessFile = new RandomAccessFile(
						tmpFile, "rw");
				randomAccessFile.setLength(0);
				randomAccessFile.close();
			}

			do
			{
				synchronized (tmpFile)
				{

					writer = new BufferedWriter(new FileWriter(tmpFile, false));
					writer.write(funcSpecific);
					writer.newLine();
					writer.close();
				}
			} while (writer == null);
			writer = null;
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

	}
	public void setFuncSpecific(BufferedReader funcSpecific)
	{
		BufferedWriter writer = null;
		// this.funcSpecific = new String(funcSpecific);

		try
		{
			if (tmpFile == null)
				tmpFile = Util.createTempFile();
			else
			{
				RandomAccessFile randomAccessFile = new RandomAccessFile(
						tmpFile, "rw");
				randomAccessFile.setLength(0);
				randomAccessFile.close();
			}
			do
			{
				synchronized (tmpFile)
				{
					writer = new BufferedWriter(new FileWriter(tmpFile, false));
					String buf;
					do
					{
						buf = funcSpecific.readLine();
						if (buf != null)
						{
							writer.write(buf);
							writer.newLine();
							writer.flush();
						}
					} while (buf != null);
					writer.close();

				}
			} while (writer == null);
			writer = null;
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

	}

	/**
	 * @param identityNumber
	 *            the identityNumber to set
	 */
	public void setIdentityNumber(int identityNumber)
	{
		this.identityNumber = identityNumber;
	}
	/**
	 * 
	 */
	public void setPbest(double score)
	{
		bestScore = score;
		this.pbest = new Vector<Double>(mPosition);
	}
	/**
	 * @param position
	 *            The mPosition to set.
	 */
	public void setPosition(Vector<Double> position)
	{
		mPreviousPosition = mPosition;
		mPosition = position;
	}
	public void setPosition(String position)
	{
		try
		{
			mPreviousPosition = mPosition;
			mPosition = new Vector<Double>();
			position = position.replace("[", "");
			position = position.replace("]", "");
			String[] a = position.split(",");
			for (int i = 0; i < a.length; i++)
			{
				mPosition.add(Double.valueOf(a[i]));
			}
		} catch (NumberFormatException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param testFunction
	 *            the testFunction to set
	 */
	public void setTestFunction(TestBase testFunction)
	{
		this.testFunction = testFunction;
	}

	/**
	 * @param velocity
	 *            The mVelocity to set.
	 */
	public void setVelocity(Vector<Double> velocity)
	{
		mVelocity = velocity;
	}
	public void setVelocity(String velocity)
	{
		try
		{
			mVelocity = new Vector<Double>();
			velocity = velocity.replace("[", "");
			velocity = velocity.replace("]", "");
			String[] a = velocity.split(",");
			for (int i = 0; i < a.length; i++)
			{
				mVelocity.add(Double.valueOf(a[i]));
			}
		} catch (NumberFormatException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setFuncSpecific(String funcSpecific, boolean reset)
	{
		// this.funcSpecific = new String(funcSpecific);

		try
		{
			if (funcSpecific == null)
				reset = true;
			// this is done due to problems with FileWriter not clearing the
			// file and effectively appending content when it shouldn't
			if (tmpFile == null)
				tmpFile = Util.createTempFile();
			if (tmpFile.exists())
			{
				if (reset)
				{
					// tmpFile.delete();
					// tmpFile = null;

					RandomAccessFile randomAccessFile = new RandomAccessFile(
							tmpFile, "rw");
					randomAccessFile.setLength(0);
					randomAccessFile.close();
				}
				BufferedWriter writer = null;
				do
				{
					synchronized (tmpFile)
					{
						writer = new BufferedWriter(
								new FileWriter(tmpFile, !reset));

						writer.append(funcSpecific);
						writer.newLine();
						writer.flush();
						writer.close();
					}
				} while (writer == null);
				writer = null;
			} else
				tmpFile = null;
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

	}

	public File retrieveFileBuffer()
	{

		File file = null;
		try
		{
			if (tmpFile != null)
			{
				file = Util.createTempFile();
				Util.copyFile(tmpFile, file);
			}
		} catch (Exception e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}
		return file;
	}

}
