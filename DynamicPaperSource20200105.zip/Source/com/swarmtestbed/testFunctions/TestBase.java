/*
 * Created on 13-Mar-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.swarmtestbed.testFunctions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.Level;

import com.swarmtestbed.data.ReadData;
import com.swarmtestbed.util.Log;
import com.swarmtestbed.util.Particle;
import com.swarmtestbed.util.Util;

/**
 * @author Ian Kenny
 * 
 *         Basic abstract class defining a test function
 * 
 */

public abstract class TestBase implements Cloneable
{
	/**
	 * 
	 */
	private static final int BUFFER_SIZE = 4096;
	protected ArrayList<Vector<Object>> data = null;
	protected ReadData db = null;
	protected String description = "";
	protected double functEval = 0;
	protected String info = "";
	protected double mBestKnown = Double.NaN;
	protected int mDimension = 10;
	protected double mGlobalOptima = 0;
	protected boolean minimised = true;
	protected double mMax[];
	protected double mMin[];
	protected double mResult = Double.NaN;
	protected Properties params;
	protected ArrayList<Vector<Object>> testdata = null;
	protected double threshold = 1.e-7;
	protected File tmpFile = null;
	protected ArrayList<Vector<Object>> traindata = null;

	/**
	 * 
	 */
	public TestBase()
	{
		super();
		params = new Properties();
		createParams();
		// setRange();
		functEval = 0;

	}
	public Object clone()
	{
		try
		{
			TestBase clone = (TestBase) super.clone();
			tmpFile = null;
			return clone;
		} catch (CloneNotSupportedException e)
		{
			throw new InternalError(e.toString());
		}
	}
	/**
	 * @return success or failure
	 * @throws Exception
	 */
	protected boolean constraints() throws Exception
	{
		return true;
	}

	abstract protected void createParams();
	public synchronized void destory()
	{
		if (tmpFile != null)
		{
			tmpFile.delete();
			tmpFile = null;
		}
	}
	protected void finalize() throws Throwable
	{
		destory();
	}

	public String getDescription()
	{
		return description;
	}
	public String getFuncSpecific()
	{

		String funcSpecific = "";
		if (tmpFile != null)
		{
			synchronized (tmpFile)
			{
				BufferedReader reader = null;
				do
				{
					try
					{
						reader = new BufferedReader(new FileReader(tmpFile));
						String line;
						while ((line = reader.readLine()) != null)
							funcSpecific += line;
						reader.close();

					} catch (IOException e)
					{
						Log.log(Level.SEVERE, e);
						e.printStackTrace();
					}
				} while (reader == null);
				reader = null;
			}
		}
		return funcSpecific;
	}
	public synchronized BufferedReader getFuncSpecificReader()
	{
		BufferedReader reader = null;
		if (tmpFile != null)
		{
			synchronized (tmpFile)
			{
				try
				{
					do
					{
						if (tmpFile != null)
							reader = new BufferedReader(
									new FileReader(tmpFile));

					} while (reader == null);

				} catch (IOException e)
				{
					Log.log(Level.SEVERE, e);
					e.printStackTrace();
				}
			}
		}
		return reader;
	}

	/**
	 * @return Returns the functEval.
	 */
	public double getFunctEval()
	{
		return functEval;
	}
	public String getInfo()
	{
		return info;
	}

	/**
	 * @return key property
	 */
	public String getKey()
	{
		return params.getProperty("key", null);
	}
	/**
	 * @return Returns the mMax for the ith dimension.
	 */
	public double getMax(int i)
	{
		Double d = null;
		try
		{
			if (mMax != null)
				d = Double.valueOf(mMax[i]);
		} catch (Exception e)
		{
			Log.log(Level.SEVERE,
					new Exception("i=" + i + " mMax size=" + mMax.length, e));
			e.printStackTrace();
		}
		return (d == null) ? Double.NaN : d.doubleValue();

	}
	/**
	 * @return Returns the mBestKnown.
	 */
	public double getMBestKnown()
	{
		return mBestKnown;
	}

	/**
	 * @return Returns the mDimension.
	 */
	public int getMDimension()
	{
		return mDimension;
	}
	/**
	 * @return the mGlobalOptima
	 */
	public double getMGlobalOptima()
	{
		return mGlobalOptima;
	}
	/**
	 * @return Returns the mMin for the ith dimension.
	 */
	public double getMin(int i)
	{
		Double d = null;
		try
		{
			if (mMin != null)
				d = Double.valueOf(mMin[i]);
		} catch (Exception e)
		{
			Log.log(Level.SEVERE,
					new Exception("i=" + i + " mMax size=" + mMax.length, e));
			e.printStackTrace();

		}
		return (d == null) ? Double.NaN : d.doubleValue();
	}
	public int getNumKeys()
	{
		return 0;
	}
	/**
	 * @return the params
	 */
	public Properties getParams()
	{
		return params;
	}
	/**
	 * @return the threshold
	 */
	public double getThreshold()
	{
		return threshold;
	}

	abstract public void init();

	/**
	 * @return Returns minimised
	 */
	public boolean isMinimised()
	{
		return minimised;
	}
	public void load(Properties props)
	{
		if (props != null)
		{
			params.clear();
			createParams();
			Enumeration<Object> keys = params.keys();
			while (keys.hasMoreElements())
			{
				String key = (String) keys.nextElement();
				if (props.containsKey(key))
					params.setProperty(key, props.getProperty(key));
			}
		}
	}
	public Particle max(ArrayList<Particle> arrayList)
	{
		Particle maxParticle = null;
		if (arrayList != null)
		{
			try
			{
				maxParticle = arrayList.get(0);
				for (Iterator<Particle> iter = arrayList.iterator(); iter
						.hasNext();)
				{
					Particle element = (Particle) iter.next();
					if (element.getBestScore() > maxParticle.getBestScore())
						maxParticle = element;

				}
			} catch (Exception e)
			{
				if (arrayList.size() == 0)
					System.err.println(
							"There are no particles in the neighbourhood");
				else
				{
					Log.log(Level.SEVERE, e);
					e.printStackTrace();
				}

			}
		}
		return maxParticle;
	}
	public Particle min(ArrayList<Particle> arrayList)
	{
		Particle minParticle = null;
		if (arrayList != null)
		{
			try
			{
				minParticle = arrayList.get(0);
				for (Iterator<Particle> iter = arrayList.iterator(); iter
						.hasNext();)
				{
					Particle element = (Particle) iter.next();
					if (element.getBestScore() < minParticle.getBestScore())
						minParticle = element;

				}
			} catch (Exception e)
			{
				if (arrayList.isEmpty())
					System.err.println(
							"There are no particles in the neighbourhood");
				else
				{
					Log.log(Level.SEVERE, e);
					e.printStackTrace();
				}
			}
		}
		return minParticle;
	}
	/**
	 * Base Objective function ** this must be called by inheriting objective
	 * functions ** ** must be coded as reentrant
	 * 
	 * @param particle
	 *            ; vector to evaluate
	 * @return dblScore; evaluated score
	 */
	public double Objective(Particle particle)
	{
		functEval++;
		if (Double.isNaN(mBestKnown))
			mBestKnown = mResult;
		if (minimised)
		{
			if (mBestKnown > mResult)
				mBestKnown = mResult;
		} else
		{
			if (mBestKnown < mResult)
				mBestKnown = mResult;
		}
		return mResult;
	}
	/**
	 * Base Objective function ** this must be called by inheriting objective
	 * functions ** This is the co-evolve version
	 * 
	 * @param v1
	 *            , v2; vectors to evaluate
	 * @return dblScore; evaluated score
	 */
	protected double Objective(Vector<Double> v1, Vector<Double> v2)
	{
		functEval++;
		if (mBestKnown == Double.NaN)
			mBestKnown = mResult;
		if (minimised)
		{
			if (mBestKnown > mResult)
				mBestKnown = mResult;
		} else
		{
			if (mBestKnown < mResult)
				mBestKnown = mResult;
		}
		return mResult;
	}
	public void reset()
	{

	}
	protected void runTest(Particle gbest)
	{
		gbest = new Particle(gbest);
		gbest.setIdentityNumber(Integer.MIN_VALUE);
		traindata = data;

		try
		{
			if (testdata == null)
			{
				db.useTestData();
				testdata = db.getData();
			}
			data = testdata;
			Objective(gbest);
		} catch (Exception e)
		{
			Log.log(Level.SEVERE, e);
//			e.printStackTrace();
		}
		data = traindata;
	}

	/**
	 * @param description
	 *            The description to set.
	 */
	protected void setDescription(String description)
	{
		this.description = description;
	}
	/**
	 * @param funcSpecific
	 *            the funcSpecific to set
	 */
	public void setFuncSpecific(String funcSpecific, boolean reset)
	{
		// this.funcSpecific = new String(funcSpecific);

		try
		{
			if (funcSpecific == null || funcSpecific.equals(""))
				reset = true;
			// this is done due to problems with FileWriter on Windows not
			// clearing the
			// file and effectively appending content when it shouldn't

			if (tmpFile == null)
				tmpFile = Util.createTempFile();
			else if (reset)
			{
//				tmpFile.delete();
//				tmpFile = null;
				new RandomAccessFile(tmpFile, "rw").setLength(0);
			}
			BufferedWriter writer = new BufferedWriter(
					new FileWriter(tmpFile, true));
			do
			{
				synchronized (tmpFile)
				{
					int index = BUFFER_SIZE;
					do
					{
						writer.append(funcSpecific.substring(
								index - (BUFFER_SIZE),
								((index + BUFFER_SIZE > funcSpecific.length())
										? funcSpecific.length()
										: index)));
						writer.newLine();
						writer.flush();
						index += BUFFER_SIZE;
					} while (index < funcSpecific.length());

					writer.close();
				}
			} while (writer == null);
			writer = null;
		} catch (IOException e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

	}
	/**
	 * @param info
	 *            The info to set.
	 */
	protected void setInfo(String info)
	{
		this.info = info;
	}
	/**
	 * @param bestKnown
	 *            the mBestKnown to set
	 */
	public void setMBestKnown(double bestKnown)
	{
		mBestKnown = bestKnown;
	}
	/**
	 * @param dimension
	 * @throws Exception
	 */
	public void setMDimension(int dimension) throws Exception
	{
		if (dimension < 1)
			throw new Exception("Dimensions must be >0");
		else
		{
			mDimension = dimension;
			params.setProperty("dimensions", Integer.toString(mDimension));
			mMax = new double[mDimension];
			mMin = new double[mDimension];
			setRange();
		}
	}
	/**
	 * @param params
	 *            the params to set
	 */
	public void setParams(Properties params)
	{

		this.params = params;
		try
		{
			setMDimension(
					Integer.parseInt(params.getProperty("dimensions", "1")));
		} catch (NumberFormatException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	abstract protected void setRange();
	/**
	 * @param threshold
	 *            the threshold to set
	 */
	public void setThreshold(double threshold)
	{
		this.threshold = threshold;
	}
	public double threshold()
	{
		return threshold - mGlobalOptima;
	}
}
