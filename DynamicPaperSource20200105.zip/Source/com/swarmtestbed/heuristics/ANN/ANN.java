/**
 * 
 */
package com.swarmtestbed.heuristics.ANN;

import java.util.ArrayList;

import com.swarmtestbed.heuristics.ANN.activators.ActivationStrategy;
import com.swarmtestbed.testFunctions.TestBase;

/**
 * @author ian
 *
 */
public class ANN extends TestBase
{
    public NeuralNetwork createANN(String name,
			ArrayList<Integer> neuronsperLayer, boolean bias,
			ActivationStrategy activationStrategy)
	{
		NeuralNetwork ann = new NeuralNetwork(name);
		Layer previousLayer = null;
		Layer layer;
		for (int i = 0; i < neuronsperLayer.size(); i++)
		{
			if (bias)
			{
				Neuron biasNeuron = new Neuron(name + "." + i + ".bias",
						activationStrategy);
				layer = new Layer(name + "." + i, previousLayer, biasNeuron);
			} else
				layer = new Layer(name, previousLayer);
			for (int j = 0; j < neuronsperLayer.get(i); j++)
			{
				Neuron neuron = new Neuron(name + "." + i + "." + j,
						activationStrategy);
				layer.addNeuron(neuron);
			}

			ann.addLayer(layer);
			previousLayer = layer;
		}

		return ann;

	}

    @Override
	protected void createParams()
	{
		// TODO Auto-generated method stub

	}

	public double error(double[] result, double[] target) {
        double error = 0.0;
        for (int i=0; i<result.length; i++) {
            double diff = result[i]-target[i];
            error += diff*diff;
        }
        return error*0.5; 
    }

	public void gradientUpdate(){
    }

	@Override
	public void init()
	{
		// TODO Auto-generated method stub

	}

	@Override
	protected void setRange()
	{
		// TODO Auto-generated method stub

	}

}
