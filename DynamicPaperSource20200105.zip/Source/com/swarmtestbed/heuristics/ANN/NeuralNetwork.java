package com.swarmtestbed.heuristics.ANN;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.swarmtestbed.heuristics.ANN.activators.ActivationStrategy;
import com.swarmtestbed.testFunctions.TestBase;
import com.swarmtestbed.util.Log;

public class NeuralNetwork extends TestBase implements Serializable 
{

	private static final String INVALID_XML_FILE_FORMAT = "Invalid XML file format";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private List<Layer> layers;
	private Layer input;
	private Layer output;

	public NeuralNetwork(String name)
	{
		this.name = name;
		layers = new ArrayList<Layer>();
	}

	public NeuralNetwork copy()
	{
		NeuralNetwork copy = new NeuralNetwork(this.name);

		Layer previousLayer = null;
		for (Layer layer : layers)
		{

			Layer layerCopy;

			if (layer.hasBias())
			{
				Neuron bias = layer.getNeurons().get(0);
				Neuron biasCopy = new Neuron("0",
						bias.getActivationStrategy().copy());
				biasCopy.setOutput(bias.getOutput());
				layerCopy = new Layer(layer.getId() + "x", null, biasCopy);
			}

			else
			{
				layerCopy = new Layer(layer.getId() + "x");
			}

			layerCopy.setPreviousLayer(previousLayer);

			int biasCount = layerCopy.hasBias() ? 1 : 0;

			for (int i = biasCount; i < layer.getNeurons().size(); i++)
			{
				Neuron neuron = layer.getNeurons().get(i);

				Neuron neuronCopy = new Neuron(Integer.toString(i),
						neuron.getActivationStrategy().copy());
				neuronCopy.setOutput(neuron.getOutput());
				neuronCopy.setError(neuron.getError());

				if (neuron.getInputs().size() == 0)
				{
					layerCopy.addNeuron(neuronCopy);
				}

				else
				{
					double[] weights = neuron.getWeights();
					layerCopy.addNeuron(neuronCopy, weights);
				}
			}

			copy.addLayer(layerCopy);
			previousLayer = layerCopy;
		}

		return copy;
	}

	public void addLayer(Layer layer)
	{
		layers.add(layer);

		if (layers.size() == 1)
		{
			input = layer;
		}

		if (layers.size() > 1)
		{
			// clear the output flag on the previous output layer, but only if
			// we have more than 1 layer
			Layer previousLayer = layers.get(layers.size() - 2);
			previousLayer.setNextLayer(layer);
		}

		output = layers.get(layers.size() - 1);
	}

	public void setInputs(double[] inputs)
	{
		if (input != null)
		{

			int biasCount = input.hasBias() ? 1 : 0;

			if (input.getNeurons().size() - biasCount != inputs.length)
			{
				throw new IllegalArgumentException(
						"The number of inputs must equal the number of neurons in the input layer");
			}

			else
			{
				List<Neuron> neurons = input.getNeurons();
				for (int i = biasCount; i < neurons.size(); i++)
				{
					neurons.get(i).setOutput(inputs[i - biasCount]);
				}
			}
		}
	}

	public String getName()
	{
		return name;
	}

	public Vector<Double> getOutput()
	{

		Vector<Double> outputs = new Vector<Double>(output.getNeurons().size());

		for (int i = 1; i < layers.size(); i++)
		{
			Layer layer = layers.get(i);
			layer.feedForward();
		}

		int i = 0;
		for (Neuron neuron : output.getNeurons())
		{
			outputs.add(i, neuron.getOutput());
			i++;
		}

		return outputs;
	}

	public List<Layer> getLayers()
	{
		return layers;
	}

	public void reset()
	{
		for (Layer layer : layers)
		{
			for (Neuron neuron : layer.getNeurons())
			{
				for (Synapse synapse : neuron.getInputs())
				{
					synapse.setWeight((Math.random() * 1) - 0.5);
				}
			}
		}
	}

	public Vector<Double> getWeights()
	{

		Vector<Double> weights = new Vector<Double>();

		for (Layer layer : layers)
		{

			for (Neuron neuron : layer.getNeurons())
			{

				for (Synapse synapse : neuron.getInputs())
				{
					weights.add(synapse.getWeight());
				}
			}
		}

		return weights;
	}

	public void setWeights(Vector<Double> weights)
	{
		int i = 0;
		for (Layer layer : layers)
		{

			for (Neuron neuron : layer.getNeurons())
			{

				for (Synapse synapse : neuron.getInputs())
				{
					synapse.setWeight(weights.get(i++));
				}
			}
		}
	}

	public void copyWeightsFrom(NeuralNetwork sourceNeuralNetwork)
	{
		if (layers.size() != sourceNeuralNetwork.layers.size())
		{
			throw new IllegalArgumentException(
					"Cannot copy weights. Number of layers do not match ("
							+ sourceNeuralNetwork.layers.size()
							+ " in source versus " + layers.size()
							+ " in destination)");
		}

		int i = 0;
		for (Layer sourceLayer : sourceNeuralNetwork.layers)
		{
			Layer destinationLayer = layers.get(i);

			if (destinationLayer.getNeurons().size() != sourceLayer.getNeurons()
					.size())
			{
				throw new IllegalArgumentException(
						"Number of neurons do not match in layer " + (i + 1)
								+ "(" + sourceLayer.getNeurons().size()
								+ " in source versus "
								+ destinationLayer.getNeurons().size()
								+ " in destination)");
			}

			int j = 0;
			for (Neuron sourceNeuron : sourceLayer.getNeurons())
			{
				Neuron destinationNeuron = destinationLayer.getNeurons().get(j);

				if (destinationNeuron.getInputs().size() != sourceNeuron
						.getInputs().size())
				{
					throw new IllegalArgumentException(
							"Number of inputs to neuron " + (j + 1)
									+ " in layer " + (i + 1) + " do not match ("
									+ sourceNeuron.getInputs().size()
									+ " in source versus "
									+ destinationNeuron.getInputs().size()
									+ " in destination)");
				}

				int k = 0;
				for (Synapse sourceSynapse : sourceNeuron.getInputs())
				{
					Synapse destinationSynapse = destinationNeuron.getInputs()
							.get(k);

					destinationSynapse.setWeight(sourceSynapse.getWeight());
					k++;
				}

				j++;
			}

			i++;
		}
	}

	public void persist()
	{
		String fileName = name.replaceAll(" ", "") + "-" + new Date().getTime()
				+ ".net";
		System.out
				.println("Writing trained neural network to file " + fileName);

		ObjectOutputStream objectOutputStream = null;

		try
		{
			objectOutputStream = new ObjectOutputStream(
					new FileOutputStream(fileName));
			objectOutputStream.writeObject(this);
		}

		catch (IOException e)
		{
			System.out.println("Could not write to file: " + fileName);
			e.printStackTrace();
		}

		finally
		{
			try
			{
				if (objectOutputStream != null)
				{
					objectOutputStream.flush();
					objectOutputStream.close();
				}
			}

			catch (IOException e)
			{
				System.out.println("Could not write to file: " + fileName);
				e.printStackTrace();
			}
		}
	}
	public String getXML()
	{
		String buf;
		buf = "<ANN name = " + name + ">";
		for (Layer layer : layers)
		{
			buf += layer.getXML() + System.getProperty("line.separator");
		}
		buf = "</ANN>";
		return buf;
	}
	public NeuralNetwork load(String xml)
	{
		NeuralNetwork ann = null;
		Layer layer = null;
		Layer previousLayer = null;
		Neuron neuron = null;
		Synapse synapse = null;
		HashMap<String, Synapse> synapseMap = new HashMap<String, Synapse>();

		XMLInputFactory factory = XMLInputFactory.newInstance();
		try
		{
			XMLEventReader eventReader = factory.createXMLEventReader(
					new ByteArrayInputStream(xml.getBytes()));

			while (eventReader.hasNext())
			{
				XMLEvent event = eventReader.nextEvent();
				String elementValue;

				switch (event.getEventType())
				{
					case XMLStreamConstants.START_ELEMENT :
					{
						StartElement startElement = event.asStartElement();
						String qName = startElement.getName().getLocalPart();
						if (qName.equalsIgnoreCase("ann"))
						{
							@SuppressWarnings("unchecked")
							Iterator<Attribute> attributes = startElement
									.getAttributes();
							if (attributes.hasNext())
							{
								Attribute attr = attributes.next();
								String localPart = attr.getName()
										.getLocalPart();
								if (localPart.equalsIgnoreCase("name"))
								{
									String attrName = attr.getValue();
									ann = new NeuralNetwork(localPart);
								}
							}
						}
						if (qName.equalsIgnoreCase("layer"))
						{
							if (ann == null)
								throw new Exception(INVALID_XML_FILE_FORMAT);
							@SuppressWarnings("unchecked")
							Iterator<Attribute> attributes = startElement
									.getAttributes();
							if (attributes.hasNext())
							{
								Attribute attr = attributes.next();
								String localPart = attr.getName()
										.getLocalPart();
								if (localPart.equalsIgnoreCase("id"))
								{
									String attrName = attr.getValue();
									layer = new Layer(attrName);
								}
							}
						} else if (qName.equalsIgnoreCase("neuron"))
						{
							if (layer == null)
								throw new Exception(INVALID_XML_FILE_FORMAT);
							@SuppressWarnings("unchecked")
							Iterator<Attribute> attributes = startElement
									.getAttributes();
							String attrName = null;
							ActivationStrategy activate = null;
							if (attributes.hasNext())
							{
								Attribute attr = attributes.next();
								String localPart = attr.getName()
										.getLocalPart();
								if (localPart.equalsIgnoreCase("id"))
								{
									attrName = attr.getValue();

								}
								if (localPart.equalsIgnoreCase("activate"))
								{
									String clazz = attr.getValue();
									activate = (ActivationStrategy) Class
											.forName(clazz)
											.getDeclaredConstructor()
											.newInstance();

								}
							}

							if (attrName != null && activate != null)
								neuron = new Neuron(attrName, activate);

						} else if (qName.equalsIgnoreCase("synapse"))
						{
							if (ann == null)
								throw new Exception(INVALID_XML_FILE_FORMAT);
							@SuppressWarnings("unchecked")
							Iterator<Attribute> attributes = startElement
									.getAttributes();
							if (attributes.hasNext())
							{
								Attribute attr = attributes.next();
								String localPart = attr.getName()
										.getLocalPart();
								if (localPart.equalsIgnoreCase("id"))
								{
									String attrName = attr.getValue();
									layer = new Layer(attrName);
								}
							}
						} else
							break;
					}
					case XMLStreamConstants.CHARACTERS :
					{
						Characters characters = event.asCharacters();
						elementValue = characters.getData();
						break;
					}
					case XMLStreamConstants.END_ELEMENT :
					{
						EndElement endElement = event.asEndElement();
						String qName = endElement.getName().getLocalPart();
						if (qName.equalsIgnoreCase("ann"))
						{
//							students.add(ann);
						} else if (qName.equalsIgnoreCase("layer"))
						{
							if (previousLayer != null)
								layer.setPreviousLayer(previousLayer);
							ann.addLayer(layer);
							previousLayer = layer;
							layer = null;
						}
						else if (qName.equalsIgnoreCase("synapse"))
						{
//							ann.setName(elementValue);
						}
						break;
					}
				}
			}
		} catch (XMLStreamException e)
		{
			Log.log(Level.SEVERE, e);

			e.printStackTrace();
		} catch (Exception e)
		{
			Log.log(Level.SEVERE, e);
			e.printStackTrace();
		}

		return ann;
	}

	@Override
	protected void createParams()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void setRange()
	{
		// TODO Auto-generated method stub
		
	}

}
