package com.swarmtestbed.heuristics.ANN.generator;

/**
 * @author ian
 *
 */
public interface TrainingDataGenerator {
    TrainingData getTrainingData();
}
