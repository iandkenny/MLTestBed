/**
 * 
 */
package org.mltestbed.data.rawimport;

/**
 * @author Ian Kenny
 *
 */
public class ImportWikipedia
{

}
