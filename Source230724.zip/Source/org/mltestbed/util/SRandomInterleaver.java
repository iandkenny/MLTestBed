package org.mltestbed.util;

import java.util.Random;

/*
 * [14:17] Dhouha.Kbaier

ARP

[14:17] Dhouha.Kbaier

for (i=1;i<=NDAT;i++)

     {

      mat_ent[i]=1+((p0*i+i0)%NDAT);

     

      mat_des[mat_ent[i]]=i;

      //printf(" i= %d mat_ent_post[%d]=%d et mat_des_post[%d]=%d \n ",i,i, mat_ent_post[i],mat_ent_post[i],mat_des_post[mat_ent_post[i]]);    

     }

NDAT= 128

p0 i0 formulas from ARP

[14:20] Dhouha.Kbaier

: P0 ≈ √ 2P ⇒ P0 =√ 2*128


p0 needs to b e prime with P the size of your block


i0 =p0/2
 */

public class SRandomInterleaver {

 

    // Method to perform S-random interleaving
    public static int[] sRandomInterleave(byte[] input) {
        int length = input.length;
        int[] output = new int[length];
        int[] indexMapping = generateIndexMapping(length);

        for (int i = 0; i < length; i++) {
            output[indexMapping[i]] = input[i];
        }

        return output;
    }

    // Method to generate the S-random index mapping
    private static int[] generateIndexMapping(int length) {
        int[] indexMapping = new int[length];
        Random random = RandGen.getLastCreated();

        // Initialize the index mapping in a sequential order (0, 1, 2, ..., length-1)
        for (int i = 0; i < length; i++) {
            indexMapping[i] = i;
        }

        // Perform random swaps to create the S-random mapping
        for (int i = 0; i < length; i++) {
            int j = random.nextInt(length);
            int temp = indexMapping[i];
            indexMapping[i] = indexMapping[j];
            indexMapping[j] = temp;
        }

        return indexMapping;
    }

 

    public static void main(String[] args) {
        byte[] input = {1, 2, 3, 4, 5, 6, 7, 8};

        // Perform S-random interleaving
        int[] interleaved = sRandomInterleave(input);

        // Display the interleaved data
        System.out.print("Interleaved data: ");
        for (int b : interleaved) {
            System.out.print(b + " ");
        }
    }}
