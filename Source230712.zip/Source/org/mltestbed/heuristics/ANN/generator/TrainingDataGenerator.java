package org.mltestbed.heuristics.ANN.generator;

/**
 * @author ian
 *
 */
public interface TrainingDataGenerator {
    TrainingData getTrainingData();
}
